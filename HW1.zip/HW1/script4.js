let h = 10,
    r = a7 / 2,
    r2 = r * r,
    pi = 3.14,
    VCilindra = h * r2 * pi;

console.log (VCilindra);