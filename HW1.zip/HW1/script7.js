let S = 2000000,
    p = 10,
    years = 5;
    Pereplata = S / p * years;

console.log (Pereplata);