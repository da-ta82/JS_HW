let width = 23,
    height = 10,
    SPryam = (width * height) + ' см';

console.log (SPryam);