let a = 5,
    b = 7,
    hTrap = 10,
    STrap = (a + b)/2*hTrap;

console.log (STrap)