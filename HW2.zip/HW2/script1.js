// задание 5

{
    let a = 10;
        b = 2,
        sum = a + b,
        sub = a - b,
        mult = a * b,
        div = a / b;

    console.log(sum);
    console.log(sub);
    console.log(mult);
    console.log(div);

    if (sum > 1) console.log (sum * sum);

// задание 6

    if ((a > 2 && a < 11) || (b >= 6 && b < 14)) {
        console.log('Верно');
    }   else {
        console.log('Неверно');
    }

}