a = 8;
b = 3;

let x1 = (16 - a) / 2 + b,
    x2 = (15 * b - a) / b,
    x3 = 23780 / (3 + a + b)

console.log (x1);
console.log (x2);
console.log (x3);