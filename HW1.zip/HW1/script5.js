let rad = 5,
    rad2 = r * r,
    SKruga = pi * rad2 + 'см';

console.log (SKruga)